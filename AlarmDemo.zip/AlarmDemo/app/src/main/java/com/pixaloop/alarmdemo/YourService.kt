package com.pixaloop.alarmdemo

import android.app.Service
import android.content.Intent
import android.media.MediaPlayer
import android.os.IBinder

class YourService: Service() {
    override fun onCreate() {
        super.onCreate()

    }

    override fun onBind(intent: Intent?): IBinder? {
        TODO("Not yet implemented")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        var mp = MediaPlayer()
        mp.setDataSource("https://thevidmix.com/my_super_wallpaper/all_data/electronic/Christmas_Rock.mp3")
        mp.prepare()
        mp.setOnPreparedListener {
            mp.start()
        }
        return START_STICKY
    }
}