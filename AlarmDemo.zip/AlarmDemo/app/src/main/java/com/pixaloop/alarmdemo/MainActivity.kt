package com.pixaloop.alarmdemo

import android.app.ActivityManager
import android.app.AlarmManager
import android.app.PendingIntent
import android.app.TimePickerDialog
import android.app.TimePickerDialog.OnTimeSetListener
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat.getSystemService
import java.util.*


class MainActivity : AppCompatActivity() {

    var button: Button? = null

    val RQS_1 = 1

    var timePickerDialog: TimePickerDialog? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        button = findViewById(R.id.button)

        button!!.setOnClickListener {
            openTimePickerDialog(false)
        }
    }

    private fun openTimePickerDialog(is24r: Boolean) {
        val calendar = Calendar.getInstance()
        timePickerDialog = TimePickerDialog(
            this@MainActivity,
            onTimeSetListener, calendar[Calendar.HOUR_OF_DAY],
            calendar[Calendar.MINUTE], is24r
        )
        timePickerDialog!!.setTitle("Set Alarm Time")
        timePickerDialog!!.show()
    }

    var onTimeSetListener =
        OnTimeSetListener { view, hourOfDay, minute ->
            val calNow = Calendar.getInstance()
            val calSet = calNow.clone() as Calendar
            calSet[Calendar.HOUR_OF_DAY] = hourOfDay
            calSet[Calendar.MINUTE] = minute
            calSet[Calendar.SECOND] = 0
            calSet[Calendar.MILLISECOND] = 0
            if (calSet.compareTo(calNow) <= 0) {
                // Today Set time passed, count to tomorrow
                calSet.add(Calendar.DATE, 1)
            }
            setAlarm(calSet)
        }

    private fun setAlarm(targetCal: Calendar) {

        val intent = Intent(baseContext, AlarmReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            baseContext, RQS_1, intent, PendingIntent.FLAG_MUTABLE
        )
        val alarmManager = getSystemService(ALARM_SERVICE) as AlarmManager
        alarmManager[AlarmManager.RTC_WAKEUP, targetCal.getTimeInMillis()] = pendingIntent
    }

}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(k1: Context?, k2: Intent?) {
        Toast.makeText(k1, "Alarm received!", Toast.LENGTH_LONG).show()
        Log.e("TAG", "onReceive: Alarm received!")

        val mYourService = YourService()
        val mServiceIntent = Intent(k1, mYourService.javaClass)
        k1!!.startService(mServiceIntent)

    }
}